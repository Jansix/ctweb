import React, { useState, useEffect } from 'react'
import { FaArrowRight } from 'react-icons/fa'

// All、News分類的切換
const Tabs = ({ selectedTab, setSelectedTab }) => {
  return (
    <div className="flex space-x-4 mb-4">
      <button
        className={`px-4 py-2 ${
          selectedTab === 'all' ? 'border-b-2 border-primary' : ''
        }`}
        onClick={() => setSelectedTab('all')}
      >
        All
      </button>
      <button
        className={`px-4 py-2 ${
          selectedTab === 'news' ? 'border-b-2 border-primary' : ''
        }`}
        onClick={() => setSelectedTab('news')}
      >
        News
      </button>
    </div>
  )
}

// 分頁組件
const Pagination = ({ currentPage, totalPages, setPage }) => {
  return (
    <div className="flex justify-center mt-4">
      <button
        className="px-4 py-2 mx-1 bg-gray-700 text-white rounded disabled:opacity-50"
        onClick={() => setPage(currentPage - 1)}
        disabled={currentPage === 1}
      >
        Previous
      </button>
      {Array.from({ length: totalPages }, (_, index) => (
        <button
          key={index + 1}
          className={`px-4 py-2 mx-1 rounded ${
            currentPage === index + 1
              ? 'bg-primary text-white'
              : 'bg-gray-700 text-white'
          }`}
          onClick={() => setPage(index + 1)}
        >
          {index + 1}
        </button>
      ))}
      <button
        className="px-4 py-2 mx-1 bg-gray-700 text-white rounded disabled:opacity-50"
        onClick={() => setPage(currentPage + 1)}
        disabled={currentPage === totalPages}
      >
        Next
      </button>
    </div>
  )
}

// 布告欄組件
const Announce = ({ value = [] }) => {
  const [announceList, setAnnounceList] = useState([])
  useEffect(() => {
    setAnnounceList(value)
  }, [value])
  const [selectedTab, setSelectedTab] = useState('all') // 預設是選擇All類別
  const [currentPage, setCurrentPage] = useState(1) // 起始頁數
  const itemsPerPage = 4 //每個頁顯示四筆

  // selectedTab是all就使用全部資料否則將新聞過濾出來賦予給filteredAnnounce渲染列表
  const filteredAnnounce =
    selectedTab === 'all'
      ? announceList
      : announceList.filter((announce) => announce.type === 'news')

  // 總筆數除每頁顯示取得總頁數
  const totalPages = Math.ceil(filteredAnnounce.length / itemsPerPage)
  // 計算得到每頁要顯示的資料
  const paginatedAnnounce = filteredAnnounce.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  // 若tab異動就將當前頁數重置為1
  useEffect(() => {
    setCurrentPage(1)
  }, [selectedTab])

  return (
    <div className="bg-darkGray text-white py-20">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-3 items-center gap-6">
          <section className="space-y-7 lg:max-w-[380px]">
            <p className="text-sm opacity-50 tracking-widest font-serif translate-y-3">
              - Announce
            </p>
            <h1 className="text-2xl lg:text-3xl">Latest Announcements</h1>
            <p className="text-sm leading-6 opacity-70">
              Explore our latest features and updates
            </p>
          </section>
          <section className="col-span-2 lg:px-20">
            <Tabs selectedTab={selectedTab} setSelectedTab={setSelectedTab} />
            <div className="space-y-8 transition-all duration-500 min-h-[280px]">
              {paginatedAnnounce.map((item) => {
                return (
                  <div
                    key={item.id}
                    className="flex justify-between items-center border-b-2 border-gray pb-4 group hover:cursor-pointer"
                  >
                    <p className="text-sm opacity-75">{item.date}</p>
                    <p className="text-lg font-bold max-w-[250px]  md:max-w-[300px] truncate xl:max-w-[400px] 2xl:max-w-[550px] flex-grow">
                      {item.title}
                    </p>
                    <FaArrowRight className="text-xl text-primary group-hover:translate-x-2 transition duration-200 " />
                  </div>
                )
              })}
            </div>
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              setPage={setCurrentPage}
            />
          </section>
        </div>
      </div>
    </div>
  )
}

export default Announce
